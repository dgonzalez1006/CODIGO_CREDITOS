
def menuAdministrativo():
    print("Por favor seleccione una opción:")
    print("\t1- Programas (CRUD)")
    print("\t2- Registrar nuevo estudiante")
    print("\t3- actualización de datos de estudiante")
    print("\t4- Ver el buzon de sugerencias") 
    print("\t5- Asignar calificaciones)")
    print("\t0- Salir")
    
    
def menuEstudiante():
    print("Por favor seleccione una opción:")
    print("\t1- Ver historial de calificaciones")
    print("\t2- Cursos disponibles")
    print("\t3- Actualización de datos de estudiante")
    print("\t4- Ver historial de calificaciones") 
    print("\t5- Promedios)")
    print("\t6- Creditos restantes para grado")
    print("\t7- Noticias")
    print("\t8- Grafica de proceso academico")
    print("\t9- Requisitos para grado") 
    print("\t10- visualizacion de cursos disponibles)")
    print("\t11- Filtrar cursos por semestre")
    print("\t12- Sugerencias")
    print("\t13- Cambiar contraseña")
    print("\t14- Creditos faltantes para el grado") 
    print("\t15- Cretificado)")    
    print("\t0- Salir")

def gestionar_creditos():
    print("\nGestión de Créditos para Grado:")
    print("\t1- Crear un crédito")
    print("\t2- Leer todos los créditos")
    print("\t3- Actualizar un crédito")
    print("\t4- Eliminar un crédito")
    print("\t0- Regresar al menú principal")

def noticiasAcciones():
    print("\nGestión de Noticias:")
    print("\t1- Ver noticias")
    print("\t2- suscribirse a las noticias")
    print("\t3- Darse de baja de las noticias")
    

