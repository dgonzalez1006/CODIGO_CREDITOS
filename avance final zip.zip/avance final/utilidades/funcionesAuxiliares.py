import json

# Función para cargar los datos desde un archivo JSON
def cargar_datos(archivo):
    try:
        with open(archivo, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []  # Si el archivo no existe, retornamos una lista vacía

# Función para guardar los datos en un archivo JSON
def guardar_datos(archivo, datos):
    with open(archivo, 'w') as f:
        json.dump(datos, f, indent=4)

# Verificar si el usuario es estudiante o administrativo
def verificar_usuario(cedula, password):
    usuarios = cargar_datos()

    # Verificar si el usuario es un estudiante
    for estudiante in usuarios["estudiantes"]:
        if estudiante["cedula"] == cedula and estudiante["password"] == password:
            return estudiante

    # Verificar si el usuario es un administrativo
    for administrativo in usuarios["administrativos"]:
        if administrativo["cedula"] == cedula and administrativo["password"] == password:
            return administrativo

    return None


