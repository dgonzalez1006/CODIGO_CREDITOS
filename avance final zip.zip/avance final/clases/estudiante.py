# esta es la clase estudiante que nos permite crear estudiantes, agregarles cursos y ver el historial
class Estudiante:
    def __init__(self, nombre, id, correo, carrera, contraseña):
        self.nombre = nombre
        self.id = id
        self.correo = correo
        self.carrera = carrera
        self.contraseña = contraseña 
        self.historialCursos = []
        
    def agregar_curso(self, curso):
        self.historialCursos.append(curso)

    def ver_historial(self):
        return self.historialCursos
    


