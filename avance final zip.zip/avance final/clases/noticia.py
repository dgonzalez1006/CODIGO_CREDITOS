# clases/noticia.py

class Noticia:
    def __init__(self, id_noticia, titulo, descripcion):
        self.id_noticia = id_noticia  # ID único para la noticia
        self.titulo = titulo
        self.descripcion = descripcion
        self.suscriptores = []  # Lista de estudiantes suscritos
       
    def agregar_suscriptor(self, estudiante_id):
        if estudiante_id not in self.suscriptores:
            self.suscriptores.append(estudiante_id)
            print(f"Estudiante {estudiante_id} se ha suscrito a la noticia: {self.titulo}")
        else:
            print(f"El estudiante {estudiante_id} ya está suscrito a esta noticia.")
    
    def eliminar_suscriptor(self, estudiante_id):
        if estudiante_id in self.suscriptores:
            self.suscriptores.remove(estudiante_id)
            print(f"Estudiante {estudiante_id} se ha dado de baja de la noticia: {self.titulo}")
        else:
            print(f"El estudiante {estudiante_id} no estaba suscrito a esta noticia.")
