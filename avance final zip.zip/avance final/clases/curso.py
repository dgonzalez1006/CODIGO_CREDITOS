# esta es la clase curso la cual tiene como parametros nombre, codigo, creditos y semestre, tiene la funcion mostrar detalles.
class Curso:
    def __init__(self, nombre, codigo, creditos, semestre):
        self.nombre = nombre
        self.codigo = codigo
        self.creditos = creditos
        self.semestre = semestre

    def mostrar_detalles(self):
        return f"{self.nombre} ({self.codigo}) - Créditos: {self.creditos}, Semestre: {self.semestre}"
