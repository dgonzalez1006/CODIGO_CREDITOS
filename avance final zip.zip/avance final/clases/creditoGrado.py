class CreditoGrado:
    def __init__(self, estudiante_id, nombre, correo, carrera, rol, historialCursos, calificaciones_por_mes):
        self.estudiante_id = estudiante_id
        self.nombre = nombre
        self.correo = correo
        self.carrera = carrera
        self.rol = rol
        self.historialCursos = historialCursos  # Lista de cursos
        self.calificaciones_por_mes = calificaciones_por_mes  # Calificaciones por mes
        self.creditosTotales = sum(curso['creditos'] for curso in historialCursos)  # Sumar créditos de los cursos
        self.creditosCursados = 0  # Créditos que el estudiante ha cursado hasta el momento
        self.creditosPendientes = self.creditosTotales  # Inicialmente todos los créditos están pendientes

    def agregar_calificacion(self, codigo_curso, mes, calificacion):
        if mes not in self.calificaciones_por_mes:
            self.calificaciones_por_mes[mes] = {}
        self.calificaciones_por_mes[mes][codigo_curso] = calificacion

    def actualizar_creditos_cursados(self, creditos):
        self.creditosCursados += creditos
        self.creditosPendientes = self.creditosTotales - self.creditosCursados
