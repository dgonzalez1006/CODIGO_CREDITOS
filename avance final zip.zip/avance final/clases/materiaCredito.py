from utilidades.funcionesAuxiliares import cargar_datos, guardar_datos

class MateriaCredito:
    def __init__(self, estudiante_id, codigo_materia, nombre_materia, cantidad_creditos, semestre, tipo_credito):
        self.estudiante_id = estudiante_id
        self.codigo_materia = codigo_materia
        self.nombre_materia = nombre_materia
        self.cantidad_creditos = cantidad_creditos
        self.semestre = semestre
        self.tipo_credito = tipo_credito

# Cargar datos desde archivo JSON
def cargar_datos_creditos_materias():
    return cargar_datos('creditos_materias.json')

# Guardar datos en archivo JSON
def guardar_datos_creditos_materias(datos):
    guardar_datos('creditos_materias.json', datos)

# Crear un nuevo crédito/materia
def crear_credito_materia(estudiante_id, codigo_materia, nombre_materia, cantidad_creditos, semestre, tipo_credito):
    datos = cargar_datos_creditos_materias()
    nueva_materia = MateriaCredito(estudiante_id, codigo_materia, nombre_materia, cantidad_creditos, semestre, tipo_credito)
    
    # Buscar si ya existe un registro del estudiante, de lo contrario, crear uno
    estudiante_encontrado = False
    for registro in datos:
        if registro['estudiante_id'] == estudiante_id:
            registro['materias'].append(nueva_materia.__dict__)
            estudiante_encontrado = True
            break
    
    if not estudiante_encontrado:
        datos.append({
            'estudiante_id': estudiante_id,
            'materias': [nueva_materia.__dict__]
        })
    
    guardar_datos_creditos_materias(datos)
    print(f"Crédito y materia {nombre_materia} creado para el estudiante {estudiante_id}")

# Leer todos los créditos y materias
def leer_creditos_materias():
    datos = cargar_datos_creditos_materias()
    for registro in datos:
        print(f"Estudiante ID: {registro['estudiante_id']}")
        for materia in registro['materias']:
            print(f"  Código: {materia['codigo_materia']}, Nombre: {materia['nombre_materia']}, Créditos: {materia['cantidad_creditos']}, Semestre: {materia['semestre']}, Tipo: {materia['tipo_credito']}")

# Actualizar crédito y materia
def actualizar_credito_materia(estudiante_id, codigo_materia, cantidad_creditos=None, semestre=None, tipo_credito=None):
    datos = cargar_datos_creditos_materias()
    for registro in datos:
        if registro['estudiante_id'] == estudiante_id:
            for materia in registro['materias']:
                if materia['codigo_materia'] == codigo_materia:
                    if cantidad_creditos is not None:
                        materia['cantidad_creditos'] = cantidad_creditos
                    if semestre is not None:
                        materia['semestre'] = semestre
                    if tipo_credito is not None:
                        materia['tipo_credito'] = tipo_credito
                    guardar_datos_creditos_materias(datos)
                    print(f"Materia {codigo_materia} actualizada para el estudiante {estudiante_id}")
                    return
    print(f"No se encontró la materia {codigo_materia} para el estudiante {estudiante_id}")

# Eliminar crédito y materia
def eliminar_credito_materia(estudiante_id, codigo_materia):
    datos = cargar_datos_creditos_materias()
    for registro in datos:
        if registro['estudiante_id'] == estudiante_id:
            registro['materias'] = [materia for materia in registro['materias'] if materia['codigo_materia'] != codigo_materia]
            if not registro['materias']:
                datos.remove(registro)  # Eliminar el estudiante si no tiene materias
            guardar_datos_creditos_materias(datos)
            print(f"Materia {codigo_materia} eliminada para el estudiante {estudiante_id}")
            return
    print(f"No se encontró la materia {codigo_materia} para el estudiante {estudiante_id}")
