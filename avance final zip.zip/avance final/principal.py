from logica.login import login

def main():
        correo = input("Ingresa tu correo: ")
        contraseña = input("Ingresa tu contraseña: ")
    
     # Llamar a la función login con los datos ingresados
        resultado = login(correo, contraseña)
    
     # Mostrar el resultado
        print(resultado)



if __name__ == "__main__":
    main()
