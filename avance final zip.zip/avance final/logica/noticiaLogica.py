from clases.noticia import Noticia
from utilidades.funcionesAuxiliares import cargar_datos, guardar_datos

# Cargar las noticias desde el archivo JSON
def cargar_noticias():
    return cargar_datos('noticias.json')

# Guardar las noticias en el archivo JSON
def guardar_noticias(noticias):
    guardar_datos('noticias.json', noticias)

# Crear una nueva noticia
def crear_noticia(titulo, descripcion):
    noticias = cargar_noticias()  # Cargar las noticias existentes
    id_noticia = generar_id_unico(noticias)
    nueva_noticia = Noticia(id_noticia, titulo, descripcion)
    noticias.append(nueva_noticia.__dict__)  # Agregar la nueva noticia
    guardar_noticias(noticias)
    print(f"Noticia '{titulo}' creada exitosamente.")

# Generar un ID único para cada noticia
def generar_id_unico(noticias):
    return max((noticia['id_noticia'] for noticia in noticias), default=0) + 1

# Suscribir a un estudiante a una noticia
def suscribir_estudiante_a_noticia(estudiante_id, id_noticia):
    noticias = cargar_noticias()
    for noticia in noticias:
        if noticia['id_noticia'] == id_noticia:
            noticia_obj = Noticia(noticia['id_noticia'], noticia['titulo'], noticia['descripcion'])
            noticia_obj.agregar_suscriptor(estudiante_id)  # Usar el método de la clase
            guardar_noticias(noticias)  # Guardar los cambios
            return
    print(f"No se encontró la noticia con ID {id_noticia}")

# Darse de baja de una noticia
def eliminar_suscripcion_estudiante(estudiante_id, id_noticia):
    noticias = cargar_noticias()
    for noticia in noticias:
        if noticia['id_noticia'] == id_noticia:
            noticia_obj = Noticia(noticia['id_noticia'], noticia['titulo'], noticia['descripcion'])
            noticia_obj.eliminar_suscriptor(estudiante_id)  # Usar el método de la clase
            guardar_noticias(noticias)  # Guardar los cambios
            return
    print(f"No se encontró la noticia con ID {id_noticia}")

# Mostrar las noticias y sus suscriptores
def mostrar_noticias():
    noticias = cargar_noticias()
    for noticia in noticias:
        print(f"ID: {noticia['id_noticia']} - Título: {noticia['titulo']}")
        print(f"Descripción: {noticia['descripcion']}")
        print(f"Suscriptores: {', '.join(str(suscriptor) for suscriptor in noticia['suscriptores'])}")
        print("\n")
