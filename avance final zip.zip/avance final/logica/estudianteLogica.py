from utilidades.funcionesAuxiliares import cargar_datos, guardar_datos

# Archivo JSON donde se almacenan los estudiantes
ARCHIVO_ESTUDIANTES = 'estudiantes.json'

def cargar_estudiantes():
    return cargar_datos(ARCHIVO_ESTUDIANTES)

def guardar_estudiantes(estudiantes):
    guardar_datos(ARCHIVO_ESTUDIANTES, estudiantes)

def registrar_estudiante(nombre, correo, carrera, contraseña): 
    estudiantes = cargar_estudiantes()
    id = generar_id_unico(estudiantes)

    nuevo_estudiante = {
        "id": id,
        "nombre": nombre,
        "correo": correo,
        "carrera": carrera,
        "contraseña": contraseña,
        "creditos_cursados": 0,
        "credito_requerido": 120,
        "historialCursos": []
    }
    
    estudiantes.append(nuevo_estudiante)
    guardar_estudiantes(estudiantes)
    print(f"Estudiante {nombre} registrado con éxito!")

def generar_id_unico(estudiantes):
    return max((estudiante["id"] for estudiante in estudiantes), default=0) + 1

def actualizar_creditos(id_estudiante, creditos):
    estudiantes = cargar_estudiantes()
    for estudiante in estudiantes:
        if estudiante["id"] == id_estudiante:
            estudiante["creditos_cursados"] += creditos
            guardar_estudiantes(estudiantes)
            print(f"Se han añadido {creditos} créditos al estudiante {estudiante['nombre']}.")
            return
    print("Estudiante no encontrado.")

def obtener_creditos_cursados(id_estudiante):
    estudiantes = cargar_estudiantes()
    for estudiante in estudiantes:
        if estudiante["id"] == id_estudiante:
            print(f"El estudiante {estudiante['nombre']} ha cursado {estudiante['creditos_cursados']} créditos.")
            return estudiante["creditos_cursados"]
    print("Estudiante no encontrado.")
    return 0

def obtener_creditos_faltantes(id_estudiante):
    estudiantes = cargar_estudiantes()
    for estudiante in estudiantes:
        if estudiante["id"] == id_estudiante:
            faltantes = estudiante["credito_requerido"] - estudiante["creditos_cursados"]
            print(f"El estudiante {estudiante['nombre']} necesita {faltantes} créditos para graduarse.")
            return faltantes
    print("Estudiante no encontrado.")
    return 0

def calcular_promedio_creditos(id_estudiante, periodo):
    estudiantes = cargar_estudiantes()
    for estudiante in estudiantes:
        if estudiante["id"] == id_estudiante:
            historial = estudiante.get("historialCursos", [])
            total_creditos = sum(curso["creditos"] for curso in historial if curso["semestre"].startswith(periodo))
            print(f"Promedio de créditos para el {periodo}: {total_creditos}")
            return total_creditos
    print("Estudiante no encontrado.")
    return 0

def actualizar_estudiante(id_estudiante, nombre=None, correo=None, carrera=None):
    estudiantes = cargar_estudiantes()
    for estudiante in estudiantes:
        if estudiante["id"] == id_estudiante:
            if nombre is not None:
                estudiante["nombre"] = nombre
            if correo is not None:
                estudiante["correo"] = correo
            if carrera is not None:
                estudiante["carrera"] = carrera
            guardar_estudiantes(estudiantes)
            print(f"Datos del estudiante {id_estudiante} actualizados con éxito.")
            return
    print("Estudiante no encontrado.")
   
def buscar_estudiante(busqueda):
    estudiantes = cargar_estudiantes()
    resultados = []
    for estudiante in estudiantes:
        if busqueda.lower() in estudiante["nombre"].lower() or busqueda.lower() in estudiante["correo"].lower():
            resultados.append(estudiante)
    
    if resultados:
        print("Resultados de la búsqueda:")
        for estudiante in resultados:
            print(f"ID: {estudiante['id']}, Nombre: {estudiante['nombre']}, Correo: {estudiante['correo']}, Carrera: {estudiante['carrera']}")
    else:
        print("No se encontraron estudiantes que coincidan con la búsqueda.") 

def agregar_calificaciones(id_estudiante, mes, calificaciones):


    estudiantes = cargar_estudiantes()
    for estudiante in estudiantes:
        if estudiante["id"] == id_estudiante:
            if "calificaciones_por_mes" not in estudiante:
                estudiante["calificaciones_por_mes"] = {}
            if mes not in estudiante["calificaciones_por_mes"]:
                estudiante["calificaciones_por_mes"][mes] = {}

            # Actualiza o agrega las calificaciones
            estudiante["calificaciones_por_mes"][mes].update(calificaciones)
            guardar_estudiantes(estudiantes)
            print(f"Calificaciones para {mes} agregadas/actualizadas exitosamente para el estudiante {estudiante['nombre']}.")
            return
        
    print("Estudiante no encontrado.")
    
def calcular_promedio_anual(id_estudiante):
    """
    Calcula el promedio de calificaciones del estudiante por semestre y anual.

    Args:
        id_estudiante (int): ID del estudiante.

    Returns:
        dict: Diccionario con los promedios por semestre y anual.
    """
    estudiantes = cargar_estudiantes()
    meses_primer_semestre = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio"}
    meses_segundo_semestre = {"Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"}

    for estudiante in estudiantes:
        if estudiante["id"] == id_estudiante:
            calificaciones_por_mes = estudiante.get("calificaciones_por_mes", {})
            if not calificaciones_por_mes:
                print(f"El estudiante {estudiante['nombre']} no tiene calificaciones registradas.")
                return None

            # Sumar calificaciones y contar cursos por semestre
            suma_primer_semestre = 0
            suma_segundo_semestre = 0
            cursos_primer_semestre = 0
            cursos_segundo_semestre = 0

            for mes, cursos in calificaciones_por_mes.items():
                if mes in meses_primer_semestre:
                    suma_primer_semestre += sum(cursos.values())
                    cursos_primer_semestre += len(cursos)
                elif mes in meses_segundo_semestre:
                    suma_segundo_semestre += sum(cursos.values())
                    cursos_segundo_semestre += len(cursos)

            # Calcular promedios
            promedio_primer_semestre = (
                suma_primer_semestre / cursos_primer_semestre if cursos_primer_semestre > 0 else 0
            )
            promedio_segundo_semestre = (
                suma_segundo_semestre / cursos_segundo_semestre if cursos_segundo_semestre > 0 else 0
            )
            promedio_anual = (
                (suma_primer_semestre + suma_segundo_semestre) /
                (cursos_primer_semestre + cursos_segundo_semestre)
                if (cursos_primer_semestre + cursos_segundo_semestre) > 0 else 0
            )

            # Resultados
            resultados = {
                "promedio_primer_semestre": promedio_primer_semestre,
                "promedio_segundo_semestre": promedio_segundo_semestre,
                "promedio_anual": promedio_anual
            }
            print(f"Promedios del estudiante {estudiante['nombre']}: {resultados}")
            return resultados

    print("Estudiante no encontrado.")
    return None

def mensaje_bienvenida(id_estudiante, estudiantes):
    """Genera un mensaje de bienvenida personalizado para un estudiante."""
    for estudiante in estudiantes:
        if estudiante["id"] == id_estudiante:
            # Obtener detalles del estudiante
            nombre = estudiante["nombre"]
            carrera = estudiante["carrera"]
            semestre = estudiante["historialCursos"][0]["semestre"] if estudiante["historialCursos"] else "Semestre no disponible"
            
            # Crear el mensaje de bienvenida
            mensaje = f"¡Bienvenido(a), {nombre}!\n"
            mensaje += f"Estás en la carrera de {carrera} y actualmente estás en el {semestre}.\n"
            mensaje += "Esperamos que tengas un excelente semestre y logres todos tus objetivos académicos."
            
            # Mostrar el mensaje de bienvenida
            print(mensaje)
            return mensaje
    print("Estudiante no encontrado.")
    return None
