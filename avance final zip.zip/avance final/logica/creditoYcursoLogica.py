from utilidades.funcionesAuxiliares import cargar_datos, guardar_datos

# Cargar los cursos desde el archivo JSON
def cargar_creditos_cursos():
    return cargar_datos('creditos_cursos.json')

# Guardar los cursos en el archivo JSON
def guardar_creditos_cursos(cursos):
    guardar_datos('creditos_cursos.json', cursos)

# Crear un nuevo curso
def crear_curso(nombre, codigo, creditos, semestre):
    cursos = cargar_creditos_cursos()  # Cargar cursos existentes
    nuevo_curso = {
        "nombre": nombre,
        "codigo": codigo,
        "creditos": creditos,
        "semestre": semestre
    }
    cursos.append(nuevo_curso)  # Agregar el nuevo curso
    guardar_creditos_cursos(cursos)
    print(f"Curso '{nombre}' con código '{codigo}', {creditos} créditos para el {semestre} agregado.")

# Leer todos los cursos
def leer_creditos_cursos():
    cursos = cargar_creditos_cursos()
    for curso in cursos:
        print(f"Curso: {curso['nombre']} | Código: {curso['codigo']} | Créditos: {curso['creditos']} | Semestre: {curso['semestre']}")

# Actualizar un curso (modificar el nombre, código, créditos o semestre)
def actualizar_curso(codigo_antiguo, nuevo_nombre, nuevo_codigo, nuevos_creditos, nuevo_semestre):
    cursos = cargar_creditos_cursos()
    for curso in cursos:
        if curso['codigo'] == codigo_antiguo:
            curso['nombre'] = nuevo_nombre
            curso['codigo'] = nuevo_codigo
            curso['creditos'] = nuevos_creditos
            curso['semestre'] = nuevo_semestre
            guardar_creditos_cursos(cursos)
            print(f"Curso actualizado: '{nuevo_nombre}' con código '{nuevo_codigo}', {nuevos_creditos} créditos para el {nuevo_semestre}.")
            return
    print(f"No se encontró el curso con código '{codigo_antiguo}'")

# Eliminar un curso
def eliminar_curso(codigo):
    cursos = cargar_creditos_cursos()
    cursos_filtrados = [curso for curso in cursos if curso['codigo'] != codigo]
    if len(cursos) == len(cursos_filtrados):
        print(f"No se encontró el curso con código '{codigo}'")
    else:
        guardar_creditos_cursos(cursos_filtrados)
        print(f"Curso con código '{codigo}' eliminado.")
        
        
# Función para mostrar los cursos disponibles que el estudiante aún no ha cursado
def mostrar_creditos_cursos_disponibles(estudiante_id):
    cursos = cargar_creditos_cursos()  # Cargar todos los cursos desde el archivo JSON
    historialCursos = []  # Suponemos que los cursos ya cursados por el estudiante se almacenan aquí
    
    # Buscar los cursos cursados por el estudiante
    # (Puedes adaptar esto si tienes una forma de obtener los cursos cursados, como en un archivo o base de datos)
    # En este ejemplo, los cursos cursados se suponen guardados en una variable como lista de códigos
    # Ejemplo: creditos_cursados = ['MAT101', 'PROG102']
    
    # Filtrar cursos que no han sido cursados por el estudiante
    cursos_disponibles = [
        curso for curso in cursos if curso['codigo'] not in historialCursos
    ]
    
    # Mostrar los cursos disponibles
    if cursos_disponibles:
        print(f"Cursos disponibles para el estudiante {estudiante_id}:")
        for curso in cursos_disponibles:
            print(f"Curso: {curso['nombre']} | Código: {curso['codigo']} | Créditos: {curso['creditos']} | Semestre: {curso['semestre']}")
    else:
        print(f"El estudiante {estudiante_id} ya ha cursado todos los cursos disponibles.")

# calificaciones.py

def filtrar_cursos_por_semestre(id_estudiante, semestre, estudiantes):
    """Filtra los cursos de un estudiante según el semestre especificado."""
    for estudiante in estudiantes:
        if estudiante["id"] == id_estudiante:
            # Filtra los cursos por semestre
            cursos_filtrados = [
                curso for curso in estudiante["historialCursos"] if curso["semestre"] == semestre
            ]
            if cursos_filtrados:
                print(f"Cursos del {semestre} para {estudiante['nombre']}:")
                for curso in cursos_filtrados:
                    print(f"- {curso['nombre']} ({curso['codigo']}), Créditos: {curso['creditos']}")
                return cursos_filtrados
            else:
                print(f"No se encontraron cursos para el semestre {semestre} del estudiante {estudiante['nombre']}.")
                return []
    print("Estudiante no encontrado.")
    return []

