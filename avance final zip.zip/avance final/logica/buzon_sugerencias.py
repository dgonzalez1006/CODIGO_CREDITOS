 
from datetime import datetime
from utilidades.funcionesAuxiliares import cargar_datos, guardar_datos

# Ruta del archivo donde se almacenarán las sugerencias
ARCHIVO_SUGERENCIAS = 'sugerencias.json'

def cargar_sugerencias():
    """Carga las sugerencias desde el archivo sugerencias.json."""
    return cargar_datos(ARCHIVO_SUGERENCIAS)

def guardar_sugerencias(sugerencias):
    """Guarda las sugerencias en el archivo sugerencias.json."""
    guardar_datos(ARCHIVO_SUGERENCIAS, sugerencias)

def registrar_sugerencia(id_estudiante, nombre_estudiante, sugerencia):
    """Registra una nueva sugerencia de un estudiante."""
    sugerencias = cargar_sugerencias()
    
    # Generar un nuevo ID para la sugerencia
    id_sugerencia = generar_id_unico_sugerencia(sugerencias)
    
    # Obtener la fecha actual
    fecha_actual = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Crear la nueva sugerencia
    nueva_sugerencia = {
        "id": id_sugerencia,
        "id_estudiante": id_estudiante,
        "nombre_estudiante": nombre_estudiante,
        "sugerencia": sugerencia,
        "fecha": fecha_actual
    }
    
    # Añadir la sugerencia al listado
    sugerencias.append(nueva_sugerencia)
    
    # Guardar las sugerencias actualizadas
    guardar_sugerencias(sugerencias)
    
    print(f"Sugerencia de {nombre_estudiante} registrada con éxito.")

def generar_id_unico_sugerencia(sugerencias):
    """Genera un ID único para cada sugerencia."""
    return max((sugerencia["id"] for sugerencia in sugerencias), default=0) + 1

def mostrar_sugerencias():
    """Muestra todas las sugerencias almacenadas."""
    sugerencias = cargar_sugerencias()
    
    if sugerencias:
        print("Sugerencias recibidas:")
        for sugerencia in sugerencias:
            print(f"ID: {sugerencia['id']}")
            print(f"Estudiante: {sugerencia['nombre_estudiante']}")
            print(f"Sugerencia: {sugerencia['sugerencia']}")
            print(f"Fecha: {sugerencia['fecha']}")
            print("-" * 50)
    else:
        print("No hay sugerencias registradas.")
