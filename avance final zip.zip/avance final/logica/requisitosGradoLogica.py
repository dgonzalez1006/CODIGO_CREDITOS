from utilidades.funcionesAuxiliares import cargar_datos

def verificar_requisitos_para_grado(estudiante_id):
    estudiantes = cargar_datos('datos/estudiantes.json')
    for estudiante in estudiantes:
        if estudiante["id"] == estudiante_id:
            # Verificación de requisitos
            creditos_cursados = estudiante["creditos_cursados"]
            creditos_requeridos = estudiante["credito_requerido"]
            promedio = calcular_promedio(estudiante["historialCursos"])

            if creditos_cursados >= creditos_requeridos and promedio >= 7:
                return f"El estudiante {estudiante['nombre']} cumple con los requisitos para graduarse."
            else:
                requisitos_faltantes = []
                if creditos_cursados < creditos_requeridos:
                    requisitos_faltantes.append(f"Faltan {creditos_requeridos - creditos_cursados} créditos.")
                if promedio < 7:
                    requisitos_faltantes.append(f"El promedio es bajo: {promedio}.")

                return f"El estudiante {estudiante['nombre']} no cumple con los requisitos para graduarse. Requisitos faltantes: {', '.join(requisitos_faltantes)}"
    
    return "Estudiante no encontrado."

def calcular_promedio(historialCursos):
    total_creditos = sum(curso['creditos'] for curso in historialCursos)
    total_notas = sum(curso['nota'] * curso['creditos'] for curso in historialCursos)
    return total_notas / total_creditos if total_creditos > 0 else 0
