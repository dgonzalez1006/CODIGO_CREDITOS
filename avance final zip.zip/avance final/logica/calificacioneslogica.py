import json
from matplotlib import pyplot as plt

# Función para cargar datos desde un archivo JSON
def cargar_estudiantes(file_name='estudiantes.json'):
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"El archivo {file_name} no existe.")
        return []
    except json.JSONDecodeError:
        print(f"Error al leer el archivo {file_name}.")
        return []

# Función para obtener las calificaciones de una materia
def obtener_calificaciones_materia(calificaciones_por_mes, materia):
    meses = list(calificaciones_por_mes.keys())  # Meses
    calificaciones = [calificaciones_por_mes[mes].get(materia, 0) for mes in meses]  # Calificaciones para la materia
    return meses, calificaciones

# Función para graficar las calificaciones de un estudiante
def graficar_notas_estudiante(estudiante):
    calificaciones_por_mes = estudiante.get('calificaciones_por_mes', {})
    historial_cursos = estudiante.get('historialCursos', [])
    
    # Crear la figura para el gráfico
    plt.figure(figsize=(10, 6))
    
    # Iterar sobre los cursos del estudiante
    for curso in historial_cursos:
        materia = curso['codigo']
        meses, calificaciones = obtener_calificaciones_materia(calificaciones_por_mes, materia)
        plt.plot(meses, calificaciones, marker='o', label=f"Calificaciones {materia}")
    
    # Títulos y etiquetas
    plt.title(f"Progreso Académico de {estudiante['nombre']}")
    plt.xlabel('Mes')
    plt.ylabel('Calificación')
    plt.legend()  # Mostrar leyenda
    plt.xticks(rotation=45)  # Rotar los nombres de los meses
    plt.grid(True)
    
    # Mostrar gráfico
    plt.tight_layout()
    plt.show()

# Función principal para seleccionar estudiante y graficar
def menu_graficar_notas():
    estudiantes = cargar_estudiantes()  # Cargar estudiantes desde el archivo JSON
    
    # Mostrar lista de estudiantes
    print("Estudiantes registrados:")
    for estudiante in estudiantes:
        print(f"ID: {estudiante['id']}, Nombre: {estudiante['nombre']}, Correo: {estudiante['correo']}")
    
    # Solicitar ID del estudiante
    try:
        id_estudiante = int(input("Ingrese el ID del estudiante para graficar sus calificaciones: "))
        estudiante = next((e for e in estudiantes if e['id'] == id_estudiante), None)
        
        if estudiante:
            graficar_notas_estudiante(estudiante)
        else:
            print("Estudiante no encontrado.")
    except ValueError:
        print("ID no válido.")

# Llamar al menú principal
menu_graficar_notas()
