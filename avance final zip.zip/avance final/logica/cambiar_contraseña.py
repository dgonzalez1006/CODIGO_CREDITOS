import bcrypt
from utilidades.funcionesAuxiliares import cargar_datos, guardar_datos

# Archivo donde se almacenan los estudiantes
ARCHIVO_ESTUDIANTES = 'estudiantes.json'

def cargar_estudiantes():
    return cargar_datos(ARCHIVO_ESTUDIANTES)

def guardar_estudiantes(estudiantes):
    guardar_datos(ARCHIVO_ESTUDIANTES, estudiantes)

def verificar_contraseña(contraseña_actual, contraseña_hash):
    """Verifica si la contraseña actual coincide con el hash almacenado."""
    return bcrypt.checkpw(contraseña_actual.encode('utf-8'), contraseña_hash)

def cambiar_contraseña(id_estudiante, contraseña_actual, nueva_contraseña):
    estudiantes = cargar_estudiantes()
    
    # Buscar al estudiante por su ID
    for estudiante in estudiantes:
        if estudiante["id"] == id_estudiante:
            # Verificar si la contraseña actual es correcta
            if verificar_contraseña(contraseña_actual, estudiante["contraseña"]):
                # Hash de la nueva contraseña
                nueva_contraseña_hash = bcrypt.hashpw(nueva_contraseña.encode('utf-8'), bcrypt.gensalt())
                estudiante["contraseña"] = nueva_contraseña_hash  # Actualizar contraseña en el archivo
                
                # Guardar los cambios
                guardar_estudiantes(estudiantes)
                print(f"Contraseña actualizada con éxito para el estudiante {estudiante['nombre']}.")
                return
            else:
                print("La contraseña actual no es correcta.")
                return

    print("Estudiante no encontrado.")
