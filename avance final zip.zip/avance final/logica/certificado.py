from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import json
import os

# Función para cargar datos de estudiantes
def cargar_estudiantes(file_name='estudiantes.json'):
    try:
        with open(file_name, 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"El archivo {file_name} no existe.")
        return []
    except json.JSONDecodeError:
        print(f"Error al leer el archivo {file_name}.")
        return []

# Función para generar el certificado
def generar_certificado(estudiante):
    nombre_archivo = f"Certificado_{estudiante['id']}.pdf"
    c = canvas.Canvas(nombre_archivo, pagesize=letter)
    width, height = letter

    # Título
    c.setFont("Helvetica-Bold", 16)
    c.drawCentredString(width / 2, height - 50, "Certificado de Información Personal")

    # Información del estudiante
    c.setFont("Helvetica", 12)
    c.drawString(50, height - 100, f"Nombre: {estudiante['nombre']}")
    c.drawString(50, height - 120, f"ID: {estudiante['id']}")
    c.drawString(50, height - 140, f"Correo: {estudiante['correo']}")
    c.drawString(50, height - 160, f"Carrera: {estudiante['carrera']}")
    c.drawString(50, height - 180, f"Créditos Cursados: {estudiante.get('creditos_cursados', 0)}")
    c.drawString(50, height - 200, f"Créditos Requeridos: {estudiante.get('credito_requerido', 120)}")

    # Historial de cursos
    c.drawString(50, height - 240, "Historial de Cursos:")
    c.setFont("Helvetica-Oblique", 10)
    y = height - 260
    for curso in estudiante['historialCursos']:
        c.drawString(60, y, f"{curso['nombre']} ({curso['codigo']}) - {curso['semestre']}")
        y -= 20

    # Pie de página
    c.setFont("Helvetica-Oblique", 10)
    c.drawCentredString(width / 2, 50, "Este documento es generado automáticamente y tiene fines informativos.")
    
    # Guardar PDF
    c.save()
    print(f"Certificado generado: {nombre_archivo}")

# Función principal para seleccionar estudiante y generar el certificado
def menu_certificado():
    estudiantes = cargar_estudiantes()  # Cargar estudiantes desde el archivo JSON
    
    # Mostrar lista de estudiantes
    print("Estudiantes registrados:")
    for estudiante in estudiantes:
        print(f"ID: {estudiante['id']}, Nombre: {estudiante['nombre']}, Correo: {estudiante['correo']}")
    
    # Solicitar ID del estudiante
    try:
        id_estudiante = int(input("Ingrese el ID del estudiante para generar su certificado: "))
        estudiante = next((e for e in estudiantes if e['id'] == id_estudiante), None)
        
        if estudiante:
            generar_certificado(estudiante)
        else:
            print("Estudiante no encontrado.")
    except ValueError:
        print("ID no válido.")

# Llamar al menú principal
menu_certificado()
