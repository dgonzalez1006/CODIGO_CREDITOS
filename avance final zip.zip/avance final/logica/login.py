from utilidades.funcionesAuxiliares import cargar_datos

# Función para validar el login
def login(correo, contraseña):
    estudiantes = cargar_datos('estudiantes.json')  # Pasa el archivo 'estudiantes.json' como argumento
    print(estudiantes)  # Imprime los estudiantes cargados para verificar los datos

    # Buscar el estudiante por correo
    for estudiante in estudiantes:
        if estudiante['correo'] == correo:
            # Validar la contraseña
            if estudiante['contraseña'] == contraseña:
                return f"Login exitoso. Bienvenido, {estudiante['nombre']}."
            else:
                return "Contraseña incorrecta."
    
    # Si no se encuentra el correo
    return "Estudiante no encontrado."

# Función principal para ejecutar el login
def main():
    correo = input("Ingresa tu correo: ")
    contraseña = input("Ingresa tu contraseña: ")
    
    resultado = login(correo, contraseña)
    print(resultado)

if __name__ == "__main__":
    main()
